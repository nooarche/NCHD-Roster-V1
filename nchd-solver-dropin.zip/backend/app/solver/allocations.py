from typing import Iterable
from .interfaces import DatedWindow

def candidates_day_call(baseline: Iterable[DatedWindow]) -> list[DatedWindow]:
    # TODO: generate from call policy and availability
    return []

def candidates_night_call(baseline: Iterable[DatedWindow]) -> list[DatedWindow]:
    # TODO: generate from call policy and availability
    return []
